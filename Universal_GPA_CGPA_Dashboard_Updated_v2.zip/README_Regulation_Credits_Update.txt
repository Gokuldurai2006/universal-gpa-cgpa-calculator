Universal GPA & CGPA Calculator — Regulation Credit Mapping Update

Files: index.html, style.css, script.js

Update:
- Added Anna University Regulation 2021 B.E. ECE selection in Class Analysis settings.
- Added a button to load the subject-code credit mappings readable from the uploaded regulation 2021.pdf.
- Current loaded mappings: EC3452=3, EC3401=4, EC3451=3, EC3492=4, EC3491=3, GE3451=2.
- Lab credits and unmatched codes are intentionally not guessed because the scanned syllabus table is unclear for those entries. Confirm them manually in Class Settings.
- Existing Excel import, localStorage, editable review table, and GPA/CGPA calculation logic are retained.

How to use:
1. Replace the existing index.html, style.css, and script.js with these files.
2. Open Class Analysis.
3. In Class Settings, keep Anna University Regulation 2021 · B.E. ECE selected.
4. Click “Load credits from Regulation 2021 syllabus”.
5. Review the mappings, manually add unclear/missing subject credits, then upload/review student Excel and calculate.

Note: This version loads a reviewed set of credits transcribed from the syllabus; it does not OCR arbitrary new syllabus files automatically. Excel reading uses the existing XLSX CDN and therefore requires internet access.

Bulk import enhancement (October 2026):
- Class Analysis now also accepts wide grade-only spreadsheets with columns such as Student Name, Subject 1, Subject 2, etc.
- Each populated grade cell becomes an editable subject row, with Semester 1 used only when the spreadsheet has no Semester column.
- Generic columns such as Subject 1 do not identify the real subject code or credit. Before calculating, replace/add the real subject code and subject name and confirm credits through the existing Class Settings mapping or the editable review table.
- The existing one-row-per-subject format and subject-code/credit CSV import are retained.
- Class data and credit mappings continue to use the existing localStorage keys; no saved data is intentionally cleared.
